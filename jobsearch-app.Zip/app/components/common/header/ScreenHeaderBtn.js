import{Image, TouchableOpacity, Pressable} from "react-native"
import styles from "./Screenheader.style"

const ScreenHeaderBtn = ({iconUrl, dimension, handlePress})=>{
    return(
        <Pressable onPress={handlePress} style = {styles.btnContainer}>
            <Image
                source={iconUrl}
                resizeMethod="conver"
                style = {styles.btnImg(dimension)}
            />
        </Pressable>
    );
};

export default ScreenHeaderBtn;